﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MyApplication
{
    public partial class buy_medicine : Infrastructure.BaseForm
    {
        public buy_medicine()
        {
            InitializeComponent();
        }
    }
}
