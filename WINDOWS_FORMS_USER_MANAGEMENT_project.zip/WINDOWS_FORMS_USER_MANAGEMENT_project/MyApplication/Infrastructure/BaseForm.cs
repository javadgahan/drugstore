﻿using System.Linq;

namespace Infrastructure
{
	public partial class BaseForm : System.Windows.Forms.Form
	{
		public BaseForm()
		{
			InitializeComponent();
		}

		private void BaseForm_Load(object sender, System.EventArgs e)
		{
		}
	}
}
